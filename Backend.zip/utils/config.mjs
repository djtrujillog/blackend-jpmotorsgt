export default {
    SECRET :'api-login'
}